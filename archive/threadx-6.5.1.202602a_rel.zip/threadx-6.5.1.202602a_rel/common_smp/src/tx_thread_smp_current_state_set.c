/***************************************************************************
 * Copyright (c) 2024 Microsoft Corporation
 * Copyright (c) 2026-present Eclipse ThreadX contributors
 *
 * This program and the accompanying materials are made available under the
 * terms of the MIT License which is available at
 * https://opensource.org/licenses/MIT.
 *
 * SPDX-License-Identifier: MIT
 **************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** ThreadX Component                                                     */
/**                                                                       */
/**   Thread - High Level SMP Support                                     */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define TX_SOURCE_CODE
#define TX_THREAD_SMP_SOURCE_CODE


/* Include necessary system files.  */

#include "tx_api.h"
#include "tx_initialize.h"
#include "tx_timer.h"
#include "tx_thread.h"



/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _tx_thread_smp_current_state_set                   PORTABLE SMP     */
/*                                                           6.1          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Microsoft Corporation                             */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function is sets the current state to all of the cores.        */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    new_state                             New per-system state          */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _tx_initialize_kernel_enter           ThreadX entry                 */
/*                                                                        */
/**************************************************************************/
void  _tx_thread_smp_current_state_set(ULONG new_state)
{

UINT    i;

    /* Initialize the state for each to initialization.  */
    i =  ((UINT) (TX_THREAD_SMP_MAX_CORES-1));
    do
    {

        /* Set this core's state.  */
        _tx_thread_system_state[i] =  new_state;

        if (i == ((UINT) 0))
        {

            /* We are finished, exit the loop.  */
            break;
        }
        else
        {

            /* Decrement the index.  */
            i--;
        }
    } while (TX_LOOP_FOREVER);
}

