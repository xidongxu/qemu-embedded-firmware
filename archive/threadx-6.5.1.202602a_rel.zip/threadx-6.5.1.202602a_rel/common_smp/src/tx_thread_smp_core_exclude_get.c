/***************************************************************************
 * Copyright (c) 2024 Microsoft Corporation
 * Copyright (c) 2026-present Eclipse ThreadX contributors
 *
 * This program and the accompanying materials are made available under the
 * terms of the MIT License which is available at
 * https://opensource.org/licenses/MIT.
 *
 * SPDX-License-Identifier: MIT
 **************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** ThreadX Component                                                     */
/**                                                                       */
/**   Thread - High Level SMP Support                                     */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define TX_SOURCE_CODE
#define TX_THREAD_SMP_SOURCE_CODE


/* Include necessary system files.  */

#include "tx_api.h"
#include "tx_initialize.h"
#include "tx_timer.h"
#include "tx_thread.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _tx_thread_smp_core_exclude_get                    PROTABLE SMP     */
/*                                                           6.1          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Microsoft Corporation                             */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function returns the current exclusion list.                   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    thread_ptr                            Pointer to the thread         */
/*    exclusion_map_ptr                     Destination for the current   */
/*                                            exclusion list              */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    Status                                                              */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/**************************************************************************/
UINT  _tx_thread_smp_core_exclude_get(TX_THREAD *thread_ptr, ULONG *exclusion_map_ptr)
{

UINT    status;


    /* First, make sure the thread pointer is valid.  */
    if (thread_ptr == TX_NULL)
    {

        /* Return pointer error.  */
        status =  TX_THREAD_ERROR;
    }

    /* Check for valid ID.  */
    else if (thread_ptr -> tx_thread_id != TX_THREAD_ID)
    {

        /* Return pointer error.  */
        status =  TX_THREAD_ERROR;
    }

    /* Is the destination pointer NULL?  */
    else if (exclusion_map_ptr == TX_NULL)
    {

        /* Return pointer error.  */
        status =  TX_PTR_ERROR;
    }
    else
    {

        /* Save the current exclusion map in the destination.  */
        *exclusion_map_ptr =  thread_ptr -> tx_thread_smp_cores_excluded;

        /* Return a successful status.  */
        status =  TX_SUCCESS;
    }

    /* Return status.  */
    return(status);
}

