/***************************************************************************
 * Copyright (c) 2024 Microsoft Corporation
 * Copyright (c) 2026-present Eclipse ThreadX contributors
 *
 * This program and the accompanying materials are made available under the
 * terms of the MIT License which is available at
 * https://opensource.org/licenses/MIT.
 *
 * SPDX-License-Identifier: MIT
 **************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** ThreadX Component                                                     */
/**                                                                       */
/**   Module Manager                                                      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define TX_SOURCE_CODE

#include "tx_api.h"
#include "tx_queue.h"
#include "tx_thread.h"
#include "txm_module.h"

#ifndef TX_DISABLE_NOTIFY_CALLBACKS
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _txm_module_manager_queue_notify_trampoline         PORTABLE C      */
/*                                                           6.1          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Scott Larson, Microsoft Corporation                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function processes the queue notification call from ThreadX.   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    queue_ptr                         Queue pointer                     */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _txm_module_manager_callback_request  Send module callback request  */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    ThreadX                                                             */
/*                                                                        */
/**************************************************************************/
VOID  _txm_module_manager_queue_notify_trampoline(TX_QUEUE *queue_ptr)
{

TX_INTERRUPT_SAVE_AREA

TXM_MODULE_INSTANCE         *module_instance;
TXM_MODULE_CALLBACK_MESSAGE  callback_message;
TX_QUEUE                    *module_callback_queue;


    /* We now know the callback is for a module.  */

    /* Disable interrupts.  */
    TX_DISABLE

    /* Pickup the module instance pointer.  */
    module_instance =  (TXM_MODULE_INSTANCE *) queue_ptr -> tx_queue_module_instance;

    /* Determine if this module is still valid.  */
    if ((module_instance) && (module_instance -> txm_module_instance_id == TXM_MODULE_ID) &&
        (module_instance -> txm_module_instance_state == TXM_MODULE_STARTED))
    {

        /* Yes, the module is still valid.  */

        /* Pickup the module's callback message queue.  */
        module_callback_queue =  &(module_instance -> txm_module_instance_callback_request_queue);

        /* Build the queue notification message.  */
        callback_message.txm_module_callback_message_type =                  TXM_QUEUE_SEND_CALLBACK;
        callback_message.txm_module_callback_message_activation_count =      1;
        callback_message.txm_module_callback_message_application_function =  (VOID (*)(VOID)) queue_ptr -> tx_queue_send_module_notify;
        callback_message.txm_module_callback_message_param_1 =               (ALIGN_TYPE) queue_ptr;
        callback_message.txm_module_callback_message_param_2 =               0;
        callback_message.txm_module_callback_message_param_3 =               0;
        callback_message.txm_module_callback_message_param_4 =               0;
        callback_message.txm_module_callback_message_param_5 =               0;
        callback_message.txm_module_callback_message_param_6 =               0;
        callback_message.txm_module_callback_message_param_7 =               0;
        callback_message.txm_module_callback_message_param_8 =               0;
        callback_message.txm_module_callback_message_reserved1 =             0;
        callback_message.txm_module_callback_message_reserved2 =             0;

        /* Restore interrupts.  */
        TX_RESTORE

        /* Call the general processing that will place the callback on the
           module's callback request queue.  */
        _txm_module_manager_callback_request(module_callback_queue, &callback_message);
    }
    else
    {

        /* Module no longer valid.  */

        /* Error, increment the error counter and return.  */
        _txm_module_manager_callback_error_count++;

        /* Restore interrupts.  */
        TX_RESTORE
    }
}
#endif


